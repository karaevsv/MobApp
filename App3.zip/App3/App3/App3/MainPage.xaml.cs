﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace App3
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            
        }

        private void Button_OnClicked(object sender, EventArgs e)
        {
            if (LoginEntry.Text == "1" && PwdEntry.Text == "1")
            {
                Navigation.PushAsync(new Info());
            }
            else
            {
                DisplayAlert("Ошибка", "Неверный логин или пароль.", "Ок");
            }
        }

        private void Button_OnClicked1(object sender, EventArgs e)
        {
            Navigation.PushAsync(new Reg());
        }
    }
}